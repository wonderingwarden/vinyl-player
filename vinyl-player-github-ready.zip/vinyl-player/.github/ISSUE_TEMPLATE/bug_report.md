---
name: Bug report
about: Report a reproducible problem
title: "[Bug]: "
labels: bug
assignees: ""
---

## Describe the bug

A clear description of what happened.

## Steps to reproduce

1.
2.
3.

## Expected behavior

What did you expect to happen?

## Environment

- Browser and version:
- Operating system:
- Screen size:
- Audio format (if relevant):

## Additional context

Include console errors or screenshots if useful. Do not attach private audio files.
