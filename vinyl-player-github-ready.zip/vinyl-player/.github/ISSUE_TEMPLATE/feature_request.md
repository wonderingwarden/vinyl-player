---
name: Feature request
about: Suggest a focused improvement
title: "[Feature]: "
labels: enhancement
assignees: ""
---

## Problem

What user problem would this solve?

## Proposed solution

Describe the behavior you would like.

## Alternatives considered

Any other approaches you considered.

## Additional context

Screenshots or examples, if relevant.
